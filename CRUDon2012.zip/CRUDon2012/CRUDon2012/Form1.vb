﻿Imports System.Data.OleDb
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tampildata()
    End Sub

    Sub tampildata()
        konek()
        da = New OleDbDataAdapter(" select * from tmhs ", koneksi)
        dt = New DataTable
        da.Fill(dt)
        dg1.DataSource = dt
        diskonek()
    End Sub

    Private Sub bsimpan_Click(sender As Object, e As EventArgs) Handles bsimpan.Click
        konek()
        cmd = New OleDbCommand("INSERT INTO tmhs VALUES('" & tnim.Text & "','" & tnama.Text & "','" & talamat.Text & "')", koneksi)
        cmd.ExecuteNonQuery()
        MsgBox("data berhasil disimpan")
        diskonek()

        bkosongkan_Click(sender, e)
        tampildata()

    End Sub

    Private Sub bkosongkan_Click(sender As Object, e As EventArgs) Handles bkosongkan.Click
        tnim.Text = ""
        tnama.Text = ""
        talamat.Text = ""
        tnim.Focus()
    End Sub

    Private Sub tnim_TextChanged(sender As Object, e As EventArgs) Handles tnim.TextChanged


    End Sub


    Private Sub dg1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dg1.CellMouseClick
        On Error Resume Next
        tnim.Text = dg1.Rows(e.RowIndex).Cells(0).Value
        tnama.Text = dg1.Rows(e.RowIndex).Cells(1).Value
        talamat.Text = dg1.Rows(e.RowIndex).Cells(2).Value
    End Sub

    Private Sub bedit_Click(sender As Object, e As EventArgs) Handles bedit.Click
        If tnim.Text = "" Or tnama.Text = "" Or talamat.Text = "" Then
            MsgBox("data belum lengkap")
            Exit Sub
        Else
            Call konek()
            cmd = New OleDb.OleDbCommand("update tmhs set nama='" & tnama.Text & "',alamat='" & talamat.Text & ",nim ='" & tnim.Text & "',)", koneksi)
            cmd.ExecuteNonQuery()
            MsgBox("update sukses")
        End If
        Call tampildata()
    End Sub

    Private Sub bhapus_Click(sender As Object, e As EventArgs) Handles bhapus.Click
        If tnim.Text = "" Then
            MsgBox("tidak ada data yg akan dihapus")
            Exit Sub
        Else
            Call konek()
            cmd = New OleDb.OleDbCommand("delete from tmhs where nim='"& tnim.Text &"'",koneksi)
            cmd.ExecuteNonQuery()
            MsgBox("hapus data sukses")

            Call tampildata()
        End If
    End Sub
End Class
